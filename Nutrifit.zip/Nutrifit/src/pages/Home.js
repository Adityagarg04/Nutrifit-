import React from "react";

const Home = () => {
  return <h1>Welcome to NutriFit!</h1>;
};

export default Home;
