document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();

    // Get user input
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    // Simple login validation (for demo purposes)
    if (email === "user@example.com" && password === "password123") {
        // Store user login status in session
        sessionStorage.setItem("isLoggedIn", "true");

        // Redirect to dashboard
        window.location.href = "dashboard.html";
    } else {
        alert("Invalid email or password. Try again.");
    }
});
