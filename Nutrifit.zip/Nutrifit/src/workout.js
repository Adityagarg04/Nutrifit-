document.getElementById("workoutForm").addEventListener("submit", function(event) {
    event.preventDefault();

    // Get user input
    let exercise = document.getElementById("exercise").value;
    let duration = document.getElementById("duration").value;
    let calories = document.getElementById("calories").value;

    // Add workout to list
    let workoutList = document.getElementById("workoutList");
    let newWorkout = document.createElement("li");
    newWorkout.innerHTML = `🔥 ${exercise} - ${duration} min - ${calories} kcal`;
    workoutList.appendChild(newWorkout);

    // Reset form fields
    document.getElementById("exercise").value = "";
    document.getElementById("duration").value = "";
    document.getElementById("calories").value = "";

    // Update progress bar (basic logic)
    let progressBar = document.getElementById("progress-bar");
    let newWidth = Math.min(parseInt(progressBar.style.width) + 10, 100);
    progressBar.style.width = newWidth + "%";
    progressBar.innerHTML = newWidth + "%";
});
