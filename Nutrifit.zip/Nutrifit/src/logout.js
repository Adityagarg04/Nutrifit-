// Function to clear session and redirect to login page
function redirectToLogin() {
    // Clear session storage
    sessionStorage.clear();
    localStorage.clear();

    // Redirect to login page
    window.location.href = "login.html";
}
