document.getElementById("dietForm").addEventListener("submit", function(event) {
    event.preventDefault();

    // Get user input
    let meal = document.getElementById("meal").value;
    let calories = document.getElementById("calories").value;
    let time = document.getElementById("time").value;

    // Add meal to list
    let mealList = document.getElementById("mealList");
    let newMeal = document.createElement("li");
    newMeal.innerHTML = `🍽️ ${meal} - ${calories} kcal - ${time}`;
    mealList.appendChild(newMeal);

    // Reset form fields
    document.getElementById("meal").value = "";
    document.getElementById("calories").value = "";
    document.getElementById("time").value = "";

    // Update progress bar (basic logic)
    let progressBar = document.getElementById("progress-bar");
    let currentCalories = parseInt(progressBar.innerHTML) || 0;
    let newCalories = currentCalories + parseInt(calories);
    let percentage = Math.min((newCalories / 2000) * 100, 100);
    
    progressBar.style.width = percentage + "%";
    progressBar.innerHTML = newCalories + " kcal";
});
